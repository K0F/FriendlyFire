#!/bin/bash
actor -d1 -n plotter -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 20
   end

10.5.1.3 9900 :a
shell msleep 1

10.5.1.3 9900 :b
shell msleep 1

10.5.1.3 9900 :c
shell msleep 1

10.5.1.3 9900 :d
shell msleep 1

10.5.1.3 9900 :e
shell msleep 1

10.5.1.3 9900 :f
shell msleep 1

10.5.1.3 9900 :g
shell msleep 1

10.5.1.3 9900 :h
shell msleep 1

10.5.1.3 9900 :i
shell msleep 1

10.5.1.3 9900 :j
shell msleep 1

10.5.1.3 9900 :k
shell msleep 1

10.5.1.3 9900 :l
shell msleep 1

10.5.1.3 9900 :m
shell msleep 1

10.5.1.3 9900 :n
shell msleep 1

10.5.1.3 9900 :m
shell msleep 1

10.5.1.3 9900 :o
shell msleep 1

10.5.1.3 9900 :\r
shell msleep 1

CONFIG
