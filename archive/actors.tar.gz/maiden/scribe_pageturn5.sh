#!/bin/bash
actor -d1 -n scribe_pageturn5 -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 20
   end


if %counter -eq %loop
	{
	10.5.1.15 9900 :FEL10
	shell sleep 5
	}
	
10.5.1.15 9900 :FEK40
# rotate

shell msleep 500

10.5.1.15 9900 :FEK20
#extension

shell msleep 2500

10.5.1.15 9900 :FEK08
# vacuum

shell msleep 500

10.5.1.15 9900 :FEK04
# probe

shell msleep 1000

10.5.1.15 9900 :FEL04

shell msleep 200

10.5.1.15 9900 :FEL40

shell msleep 1200

10.5.1.15 9900 :FEL08
10.5.1.15 9900 :FEK80
# swing
#10.5.1.15 9900 :FEL04

shell sleep 2

10.5.1.15 9900 :FEL20

shell sleep 5

10.5.1.15 9900 :FEL80

shell sleep 2

set counter %counter+1
set loop %counter/5
set loop %loop*5
# modulus for match on 5's
shell echo  counter %counter  loop %loop

if %counter -eq %loop
	{
	10.5.1.15 9900 :FEK10
	shell sleep 5
	}


CONFIG
