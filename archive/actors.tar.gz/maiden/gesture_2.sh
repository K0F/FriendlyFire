#!/bin/bash
actor -d1 -n gesture_2 -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.15 9900 :FCK01
shell sleep 1

10.5.1.15 9900 :FCK02
shell sleep 1

10.5.1.15 9900 :FCK04
shell sleep 1

10.5.1.15 9900 :FCK08
shell sleep 1

10.5.1.15 9900 :FCK10
shell sleep 1

10.5.1.15 9900 :FCK20
shell sleep 1

10.5.1.15 9900 :FCK40
shell sleep 1

10.5.1.15 9900 :FCK80
shell sleep 1

10.5.1.15 9900 :FCK100
shell sleep 1

10.5.1.15 9900 :FCK200
shell sleep 1

10.5.1.15 9900 :FCK400
shell sleep 1

10.5.1.15 9900 :FCK800
shell sleep 1

10.5.1.15 9900 :FCL800
shell sleep 1

10.5.1.15 9900 :FCL400
shell sleep 1

10.5.1.15 9900 :FCL200
shell sleep 1

10.5.1.15 9900 :FCL100
shell sleep 1

10.5.1.15 9900 :FCL80
shell sleep 1

10.5.1.15 9900 :FCL40
shell sleep 1

10.5.1.15 9900 :FCL20
shell sleep 1

10.5.1.15 9900 :FCL10
shell sleep 1

10.5.1.15 9900 :FCL08
shell sleep 1

10.5.1.15 9900 :FCL04
shell sleep 1

10.5.1.15 9900 :FCL02
shell sleep 1

10.5.1.15 9900 :FCL01

CONFIG
