#!/bin/bash
actor -d1 -n table_area_light_on -h 10.5.1.15 -p 9850 << CONFIG
10.5.1.15 9800 midi
   note_on
   midi_channel 0 
   low   0x48 
   hi    0x48 
   low_velocity   0x01
   hi_velocity    0x70 
   end

10.5.1.10 9901 :F25\rD1-4@60\rG\r

CONFIG
