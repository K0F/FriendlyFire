#!/bin/sh
# stop disc rotation
actor -d0 -n p0-7_off -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

shell /bin/echo -n "\377" >/dev/lp2
      
CONFIG
