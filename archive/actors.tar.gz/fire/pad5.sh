#!/bin/sh
actor -d1 -n pad5 -h 10.5.1.15 -p 9850 << CONFIG
10.5.1.15 9800 midi
   note_on
   midi_channel 9 
   low   0x2e
   hi    0x2e
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

if %video_mode -eq 1
{
if %mvel -ge 1
      if %mvel -lt 15    
      10.5.1.15 9900 :0sp mf\r

if %mvel -ge 15
      {
      if %mvel -lt 29    
      10.5.1.15 9900 :4sp mf\r
      }
      
if %mvel -ge 29
      {
      if %mvel -lt 43    
      10.5.1.15 9900 :8sp mf\r
      }

if %mvel -ge 43
      {
      if %mvel -lt 57    
      10.5.1.15 9900 :15sp mf\r
      } 

if %mvel -ge 57
      {
      if %mvel -lt 71
      10.5.1.15 9900 :30sp mf\r
      }

if %mvel -ge 71
      {
      if %mvel -lt 85
      10.5.1.15 9900 :60sp mf\r
      }

if %mvel -ge 85
      {
      if %mvel -lt 99
      10.5.1.15 9900 :120sp mf\r
      }
      
if %mvel -ge 99
      {
      if %mvel -lt 113
      10.5.1.15 9900 :240sp mf\r
      }
if %mvel -ge 113
      {
      if %mvel -le 127
      10.5.1.15 9900 :255sp mf\r
      }
 }     
      
CONFIG
