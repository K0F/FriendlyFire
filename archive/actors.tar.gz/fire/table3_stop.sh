#!/bin/sh
echo stopping table3 >>/var/log/table3.log
date >>/var/log/table3.log
killall actor
sleep 1
/actors/p0-7_off.sh
/actors/video_rj.sh
