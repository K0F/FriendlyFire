#!/bin/sh
echo starting table3 actors >>/var/log/table3.log
date >>/var/log/table3.log
# the right way
#/unicom/mididd/runmidi.sh 9800 cua1 &
#the wrong ay (boo, hiss)
#(mididd -d0 9800 cua1 &)
#(logicdd -d0 9850 &)
#(serialdd -port 9900 -sdev cua0 &)
/actors/video_pl.sh
sleep 15
/actors/pad1.sh &
/actors/pad2.sh &
/actors/pad3.sh &
/actors/pad4.sh &
/actors/pad5.sh &
/actors/table3_timeline.sh &
#/actors/table3_script.sh &
