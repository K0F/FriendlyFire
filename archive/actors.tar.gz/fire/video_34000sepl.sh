#!/bin/sh
actor -d1 -n video_34000sepl -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.15 9900 :34000sepl\r

CONFIG
