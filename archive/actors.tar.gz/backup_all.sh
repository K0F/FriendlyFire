#!/bin/bash
# Unicom actor backup script
# Intended to be run nightly from a node like jonah
# Original: 5/20/98, Bruce Hamilton
# Added -v flag to copy, mods for crontab entry, 5/22/98, Gritzo
#
# Added to crontab with:
#00 02 * * *   /actors/backup_all.sh 1> /actors/backup_all.log 2>&1
#
echo Starting /actor/backup_all.sh
date
echo unmounting mount point...
umount /mnt
echo automata...
mount automata:/actors /mnt
cp -Rvf /mnt/* /actors/automata/
umount /mnt
echo fire...
mount fire:/actors /mnt
cp -Rvf /mnt/* /actors/fire/
umount /mnt
echo maiden...
mount maiden:/actors /mnt
cp -Rvf /mnt/* /actors/maiden/
umount /mnt
echo rails...
mount rails:/actors /mnt
cp -Rvf /mnt/* /actors/rails/
umount /mnt
echo scribe...
mount scribe:/actors /mnt
cp -Rvf /mnt/* /actors/scribe/
umount /mnt
