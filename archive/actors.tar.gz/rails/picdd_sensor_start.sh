#!/bin/sh
picdd_rail02_midi.sh &
picdd_rail_sensor_midi.sh &
picdd_sensor.sh &
