#!/bin/sh
picdd_stop01.sh &
picdd_stop02.sh &
picdd_stop03.sh &
picdd_stop04.sh &
picdd_stop05.sh &
picdd_stop06.sh &
picdd_stop07.sh &
