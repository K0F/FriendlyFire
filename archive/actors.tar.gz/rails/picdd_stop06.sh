#!/bin/sh
actor -d1 -n picdd_stop06 -h 10.5.1.10 -p 9850 << CONFIG
10.5.1.15 9800 midi
   note_on
   midi_channel 0 
   low   0x2d
   hi    0x2d
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

10.5.1.10 9700 :stop 06

CONFIG
