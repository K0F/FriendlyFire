#!/bin/sh
actor -d0 -n picdd_addr_all -h 10.5.1.10 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.10 9700 :addr 01 01 131
shell msleep 30
10.5.1.10 9700 :addr 04 04 132
shell msleep 30
10.5.1.10 9700 :addr 05 05 132
shell msleep 30
10.5.1.10 9700 :addr 07 07 133
shell msleep 30
10.5.1.10 9700 :addr 02 02 131
shell msleep 30
10.5.1.10 9700 :addr 03 03 131
shell msleep 30
10.5.1.10 9700 :addr 06 06 132
shell msleep 30
10.5.1.10 9700 :addr 08 08 133
shell msleep 30

CONFIG
