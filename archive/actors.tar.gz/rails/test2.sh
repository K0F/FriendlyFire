#!/bin/sh
actor -d0 -n test2 -h 192.168.2.14 -p 9850 << CONFIG
192.168.2.3 9800 midi
   note_on
   midi_channel 0 
   low   0x20 
   hi    0x70 
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

# this is a comment
shell echo here 1

if %var1 -eq 1
   {
   shell echo here 2

#  if %var2 -eq 2
#      192.168.2.10 9700 : nop 01
  }

if %mnote -eq 42
   { 
   shell echo note 2a
   192.168.2.10 9700 : nop 01
   }
   
if %mnote -eq 43
   192.168.2.14 9900 :10\r

if %mnote -eq 44
   192.168.2.14 9900 :14\r

if %mnote -eq 45
   192.168.2.14 9900 :11\r

CONFIG
