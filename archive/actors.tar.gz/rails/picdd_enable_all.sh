#!/bin/sh
actor -d0 -n picdd_enable_all -h 10.5.1.10 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.10 9700 :enable 08
shell msleep 30
10.5.1.10 9700 :enable 07
shell msleep 30
10.5.1.10 9700 :enable 06
shell msleep 30
10.5.1.10 9700 :enable 05
shell msleep 30
10.5.1.10 9700 :enable 04
shell msleep 30
10.5.1.10 9700 :enable 03
shell msleep 30
10.5.1.10 9700 :enable 02
shell msleep 30
10.5.1.10 9700 :enable 01
shell msleep 30

CONFIG
