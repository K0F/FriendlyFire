#!/bin/bash
actor -d1 -n test1 -f test1.out -h 192.168.2.3 -p 9900 << CONFIG
192.168.2.3 9800 midi
   note_on
   midi_channel 0 
   low   0x20 
   hi    0x70 
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

# this is a comment
shell echo comment 1

if %var1 -eq 1
   shell echo var1 is 1

if %mnote -eq 42
  { 
  shell echo note 2a

  if %var2 -eq 2
     192.168.2.10 9700 : nop 03
  }

set var2 0

CONFIG
