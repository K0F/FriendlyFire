#!/bin/sh
picdd_ping.sh &
picdd_right02.sh &
picdd_left02.sh &
picdd_rail02_midi.sh &
