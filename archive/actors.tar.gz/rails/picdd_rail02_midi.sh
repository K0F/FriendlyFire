#!/bin/sh
actor -d1 -n picdd_rail02_midi -h 10.5.1.10 -p 9850 << CONFIG
10.5.1.10 9700 midi
   note_on
   midi_channel 2 
   low   0x01
   hi    0x7e
   low_velocity   0x00 
   hi_velocity    0x7f 
   end

set rail02_midi %mnote

CONFIG
