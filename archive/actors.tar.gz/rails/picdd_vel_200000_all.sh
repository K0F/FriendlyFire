#!/bin/sh
actor -d0 -n picdd_vel_200000_all -h 10.5.1.10 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.10 9700 :vel 07 200000
10.5.1.10 9700 :vel 06 200000
10.5.1.10 9700 :vel 05 200000
10.5.1.10 9700 :vel 04 200000
10.5.1.10 9700 :vel 03 200000
10.5.1.10 9700 :vel 02 200000
10.5.1.10 9700 :vel 01 200000
10.5.1.10 9700 :vel 129 200000
10.5.1.10 9700 :vel 130 200000
10.5.1.10 9700 :vel 131 200000

CONFIG
