#!/bin/sh
actor -d0 -n picdd_vel_400000_all -h 10.5.1.10 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.10 9700 :vel 07 400000
10.5.1.10 9700 :vel 06 400000
10.5.1.10 9700 :vel 05 400000
10.5.1.10 9700 :vel 04 400000
10.5.1.10 9700 :vel 03 400000
10.5.1.10 9700 :vel 02 400000
10.5.1.10 9700 :vel 01 400000

CONFIG
