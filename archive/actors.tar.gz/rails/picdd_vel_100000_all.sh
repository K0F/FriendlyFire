#!/bin/sh
actor -d0 -n picdd_vel_100000_all -h 10.5.1.10 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.10 9700 :vel 07 100000
shell msleep 30
10.5.1.10 9700 :vel 06 100000
shell msleep 30
10.5.1.10 9700 :vel 05 100000
shell msleep 30
10.5.1.10 9700 :vel 04 100000
shell msleep 30
10.5.1.10 9700 :vel 03 100000
shell msleep 30
10.5.1.10 9700 :vel 02 100000
shell msleep 30
10.5.1.10 9700 :vel 01 100000
shell msleep 30
10.5.1.10 9700 :vel 131 100000
shell msleep 30
10.5.1.10 9700 :vel 132 100000
shell msleep 30
10.5.1.10 9700 :vel 133 100000
shell msleep 30

CONFIG
