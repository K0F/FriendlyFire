#!/bin/sh
actor -d0 -n picdd_kd_32000_all -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.3 9700 :kd 01 32000
shell msleep 30
10.5.1.3 9700 :kd 02 32000
shell msleep 30
10.5.1.3 9700 :kd 03 32000
shell msleep 30
10.5.1.3 9700 :kd 04 32000
shell msleep 30
10.5.1.3 9700 :kd 05 32000
shell msleep 30
10.5.1.3 9700 :kd 06 32000
shell msleep 30
10.5.1.3 9700 :kd 07 32000
shell msleep 30
10.5.1.3 9700 :kd 08 32000
shell msleep 30

CONFIG
