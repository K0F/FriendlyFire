#!/bin/sh
actor -d0 -n picdd_pos0_132 -h 10.5.1.3 -p 9850 << CONFIG
10.5.1.14 9800 midi
   note_on
   midi_channel 0 
   low   0x03
   hi    0x03
   low_velocity   0x01
   hi_velocity    0x7f 
   end


if %current3_midi -ge 80
   {
   if %go_middle_y -eq 0
      {
      10.5.1.3 9700 :stop 132
      shell msleep 700
      10.5.1.3 9700 :vel 132 50000
      10.5.1.3 9700 :vel 04 100000
      10.5.1.3 9700 :pos 132 0
      10.5.1.3 9700 :pos 04 0
      10.5.1.3 9700 :gtraj 132
      10.5.1.3 9700 :gtraj 04
      10.5.1.3 9900 :blank\r
      set go_middle_y 1
      }
   }

CONFIG
