#!/bin/sh
actor -d0 -n picdd_kp_5000_01-06 -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.3 9700 :kp 01 5000
shell msleep 30
10.5.1.3 9700 :kp 02 5000
shell msleep 30
10.5.1.3 9700 :kp 03 5000
shell msleep 30
10.5.1.3 9700 :kp 04 5000
shell msleep 30
10.5.1.3 9700 :kp 05 5000
shell msleep 30
10.5.1.3 9700 :kp 06 5000
shell msleep 30

CONFIG
