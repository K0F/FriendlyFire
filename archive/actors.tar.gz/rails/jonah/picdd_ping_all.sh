#!/bin/sh
actor -d0 -n picdd_ping_all -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 0
   end

10.5.1.3 9700 :ping 01
shell msleep 250
10.5.1.3 9700 :ping 02
shell msleep 250
10.5.1.3 9700 :ping 03
shell msleep 250
10.5.1.3 9700 :ping 04
shell msleep 250
10.5.1.3 9700 :ping 05
shell msleep 250
10.5.1.3 9700 :ping 06
shell msleep 250
10.5.1.3 9700 :ping 07
shell msleep 250
10.5.1.3 9700 :ping 08
shell msleep 250

CONFIG
