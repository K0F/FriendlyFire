#!/bin/sh
actor -d1 -n picdd_reset01_center -h 10.5.1.3 -p 9850 << CONFIG
10.5.1.3 9700 midi
   note_on
   midi_channel 1 
   low   0x01
   hi    0x01
   low_velocity   0x00 
   hi_velocity    0x00 
   end

10.5.1.3 9700 :rpos 01
shell msleep 60

10.5.1.3 9700 :pos 01 33500
shell msleep 30

10.5.1.3 9700 :gtraj 01

shell sleep 7

10.5.1.3 9700 :rpos 01

#shell find /var/run -name "actor.picdd_reset01_*.pid" -exec actorkill.sh {} \;
shell cat /var/run/actor.picdd_reset01_stat.pid | xargs kill
shell cat /var/run/actor.picdd_reset01_ping.pid | xargs kill
shell cat /var/run/actor.picdd_reset01_center.pid | xargs kill

CONFIG
