#!/bin/sh
actor -d0 -n picdd_accel_150_all -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.3 9700 :accel 07 150
10.5.1.3 9700 :accel 06 150
10.5.1.3 9700 :accel 05 150
10.5.1.3 9700 :accel 04 150
10.5.1.3 9700 :accel 03 150
10.5.1.3 9700 :accel 02 150
10.5.1.3 9700 :accel 01 150
10.5.1.3 9700 :accel 129 150
10.5.1.3 9700 :accel 130 150
10.5.1.3 9700 :accel 131 150

CONFIG
