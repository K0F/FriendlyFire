#!/bin/sh
picdd_rail08_midi.sh &
picdd_rail_sensor1_midi.sh &
picdd_sensor1.sh &
