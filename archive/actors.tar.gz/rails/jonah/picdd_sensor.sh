#!/bin/sh
actor -d1 -n picdd_sensor -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 0
   end

shell msleep 150

10.5.1.3 9700 : ping 02

shell msleep 150

set diff %rail02_midi-%sensor_midi

if %diff -ge 20
   {
   10.5.1.3 9700 :vel 130 200000
   10.5.1.3 9700 :vmode 130 for
   }
   
if %diff -lt 20
   {
      if %diff -ge 10
      {
      10.5.1.3 9700 :vel 130 100000
      10.5.1.3 9700 :vmode 130 for
      }
   }
   
if %diff -lt 10
   {
      if %diff -ge 3
      {
      10.5.1.3 9700 :vel 130 50000
      10.5.1.3 9700 :vmode 130 for
      }
   }

if %diff -lt 3
   {
      if %diff -gt -3
      {
      10.5.1.3 9700 :vel 130 0
      10.5.1.3 9700 :vmode 130 for
      }
   }

if %diff -le -20
   {
   10.5.1.3 9700 :vel 130 200000
   10.5.1.3 9700 :vmode 130 rev
   }
   
if %diff -gt -20
   {
      if %diff -le -10
      {
      10.5.1.3 9700 :vel 130 100000
      10.5.1.3 9700 :vmode 130 rev
      }
   }
   
if %diff -gt -10
   {
      if %diff -le -3
      {
      10.5.1.3 9700 :vel 130 50000
      10.5.1.3 9700 :vmode 130 rev
      }
   }
      
CONFIG
