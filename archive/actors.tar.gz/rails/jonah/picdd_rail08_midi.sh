#!/bin/sh
actor -d1 -n picdd_rail08_midi -h 10.5.1.3 -p 9850 << CONFIG
10.5.1.3 9700 midi
   note_on
   midi_channel 8 
   low   0x01
   hi    0x7e
   low_velocity   0x00 
   hi_velocity    0x7f 
   end

set rail08_midi %mnote

CONFIG
