#!/bin/sh
actor -d0 -n picdd_accel_100_300 -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.3 9700 : accel 08 100
shell msleep 30
10.5.1.3 9700 : accel 07 100
shell msleep 30
10.5.1.3 9700 : accel 06 100
shell msleep 30
10.5.1.3 9700 : accel 05 100
shell msleep 30
10.5.1.3 9700 : accel 04 200
shell msleep 30
10.5.1.3 9700 : accel 03 100
shell msleep 30
10.5.1.3 9700 : accel 02 100
shell msleep 30
10.5.1.3 9700 : accel 01 200
shell msleep 30
10.5.1.3 9700 : accel 131 100
shell msleep 30
10.5.1.3 9700 : accel 132 100
shell msleep 30
10.5.1.3 9700 : accel 133 100
shell msleep 30

CONFIG
