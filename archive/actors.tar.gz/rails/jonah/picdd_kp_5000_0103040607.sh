#!/bin/sh
actor -d0 -n picdd_kp_5000_0103040607 -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.3 9700 :kp 01 5000
10.5.1.3 9700 :gain 01
10.5.1.3 9700 :kp 03 5000
10.5.1.3 9700 :gain 03
10.5.1.3 9700 :kp 04 5000
10.5.1.3 9700 :gain 04
10.5.1.3 9700 :kp 06 5000
10.5.1.3 9700 :gain 06
10.5.1.3 9700 :kp 07 5000
10.5.1.3 9700 :gain 07
10.5.1.3 9700 :kp 129 5000
10.5.1.3 9700 :gain 129
10.5.1.3 9700 :kp 131 5000
10.5.1.3 9700 :gain 131

CONFIG
