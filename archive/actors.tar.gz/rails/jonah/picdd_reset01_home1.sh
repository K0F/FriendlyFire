#!/bin/sh
actor -d0 -n picdd_reset01_home1 -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

shell picdd_reset01_stat.sh &

shell msleep 150

10.5.1.3 9700 :stat 01

shell msleep 100

if %location01 -le 16
   {
	10.5.1.3 9700 :vel 01 200000
	10.5.1.3 9700 :vmode 01 for
	}

shell picdd_reset01_center.sh &
shell picdd_reset01_ping.sh &

shell msleep 500

#10.5.1.3 9700 :home1 01
10.5.1.3 9700 :vel 01 200000
10.5.1.3 9700 :vmode 01 rev



CONFIG
