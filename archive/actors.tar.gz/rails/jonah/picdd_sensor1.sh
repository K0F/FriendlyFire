#!/bin/sh
actor -d1 -n picdd_sensor1 -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 0
   end

shell msleep 100

10.5.1.3 9700 : ping 08

shell msleep 100

set diff1 %rail08_midi-%sensor1_midi

if %diff1 -ge 30
   {
   10.5.1.3 9700 :vel 133 300000
   10.5.1.3 9700 :vmode 133 for
   }
   
if %diff1 -lt 30
   {
      if %diff1 -ge 15
      {
      10.5.1.3 9700 :vel 133 100000
      10.5.1.3 9700 :vmode 133 for
      }
   }
   
if %diff1 -lt 15
   {
      if %diff1 -ge 3
      {
      10.5.1.3 9700 :vel 133 50000
      10.5.1.3 9700 :vmode 133 for
      }
   }

if %diff1 -lt 3
   {
      if %diff1 -gt -3
      {
      10.5.1.3 9700 :vel 133 0
      10.5.1.3 9700 :vmode 133 for
      }
   }

if %diff1 -le -30
   {
   10.5.1.3 9700 :vel 133 300000
   10.5.1.3 9700 :vmode 133 rev
   }
   
if %diff1 -gt -30
   {
      if %diff1 -le -15
      {
      10.5.1.3 9700 :vel 133 100000
      10.5.1.3 9700 :vmode 133 rev
      }
   }
   
if %diff1 -gt -15
   {
      if %diff1 -le -3
      {
      10.5.1.3 9700 :vel 133 50000
      10.5.1.3 9700 :vmode 133 rev
      }
   }
      
CONFIG
