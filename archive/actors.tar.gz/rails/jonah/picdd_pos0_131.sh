#!/bin/sh
actor -d0 -n picdd_pos0_131 -h 10.5.1.3 -p 9850 << CONFIG
10.5.1.14 9800 midi
   note_on
   midi_channel 0 
   low   0x02
   hi    0x02
   low_velocity   0x01
   hi_velocity    0x7f 
   end


if %current2_midi -ge 80
   {
   if %go_middle_x -eq 0
      {
      10.5.1.3 9700 :stop 131
      shell msleep 700
      10.5.1.3 9700 :vel 131 50000
      10.5.1.3 9700 :vel 01 100000
      10.5.1.3 9700 :pos 131 0
      10.5.1.3 9700 :pos 01 0
      10.5.1.3 9700 :gtraj 131
      10.5.1.3 9700 :gtraj 01
      10.5.1.3 9900 :blank\r
      set go_middle_x 1
      }
   }

CONFIG
