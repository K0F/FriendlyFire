#!/bin/sh
actor -d0 -n picdd_pos+10000_129 -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.3 9700 :pos 129 10000

CONFIG
