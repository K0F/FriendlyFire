#!/bin/sh
actor -d0 -n picdd_reset_all -h 10.5.1.3 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.3 9700 :reset 07
10.5.1.3 9700 :reset 06
10.5.1.3 9700 :reset 05
10.5.1.3 9700 :reset 04
10.5.1.3 9700 :reset 03
10.5.1.3 9700 :reset 02
10.5.1.3 9700 :reset 01
10.5.1.3 9700 :reset 00

CONFIG
