#!/bin/sh
actor -d0 -n picdd_accel_150_all -h 10.5.1.10 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.10 9700 :accel 08 150
shell msleep 30
10.5.1.10 9700 :accel 07 150
shell msleep 30
10.5.1.10 9700 :accel 06 150
shell msleep 30
10.5.1.10 9700 :accel 05 150
shell msleep 30
10.5.1.10 9700 :accel 04 150
shell msleep 30
10.5.1.10 9700 :accel 03 150
shell msleep 30
10.5.1.10 9700 :accel 02 150
shell msleep 30
10.5.1.10 9700 :accel 01 150
shell msleep 30
10.5.1.10 9700 :accel 131 150
shell msleep 30
10.5.1.10 9700 :accel 132 150
shell msleep 30
10.5.1.10 9700 :accel 133 150
shell msleep 30

CONFIG
