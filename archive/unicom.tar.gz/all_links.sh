./create_link.sh actor /unicom/actor/actor110
./create_link.sh logicdd /unicom/logicdd/logicdd101
./create_link.sh mididd /unicom/mididd/mididd150
./create_link.sh optodd /unicom/optodd/optodd120
./create_link.sh picdd /unicom/picdd/picdd130
./create_link.sh serialdd /unicom/serialdd/serialdd140
