#!/bin/sh
actor -d1 -n automata_midi -h 10.5.1.12 -p 9850 << CONFIG
10.5.1.12 9901 midi
   note_on
   midi_channel 0 
   low   0x7f
   hi    0x7f
   low_velocity   0x00
   hi_velocity    0x7f 
   end

set running 1

if %mvel -eq 0
	{
	10.5.1.12 9901 :aa ac200,200,200;
	10.5.1.12 9901 :aa vl500,500,400;
	10.5.1.12 9901 :aa mt-4000,0,0; gd id
	10.5.1.12 9901 :mn 90 7f 01
	}

if %mvel -eq 1
	{
#	shell /bin/echo -n "\036" >/dev/lp1
	shell /bin/echo -n "\136" >/dev/lp1
	# light 1 & 6 on
	10.5.1.12 9901 :aa vl500,500,400;
	10.5.1.12 9901 :aa ml4000,0,0; gd id
	10.5.1.12 9902 : 19369 se pl\r	
		if %compass -eq 1
		{
#		shell /sound/rsynth/say north -S 1
		10.5.1.12 9900 :\0218 north\r
		}
		if %compass -eq 2
		{
#		shell /sound/rsynth/say saskatchewan -S 1
		10.5.1.12 9900 :\0218 saskatchewan\r
		}
	10.5.1.12 9901 :mn 90 7f 02
	# go north all axes
	}

if %mvel -eq 2
	{
	shell /bin/echo -n "\127" >/dev/lp1
	# light 4 & 6 on
	10.5.1.12 9901 :rp
	10.5.1.12 9901 :aa ml4000,0,3220; gd id
	10.5.1.12 9902 : 20388 se pl\r	
		if %compass -eq 1
		{
#		shell /sound/rsynth/say west -S 1
		10.5.1.12 9900 :\0218 west\r
		}
		if %compass -eq 2
		{
#		shell /sound/rsynth/say arizona -S 1 
		10.5.1.12 9900 :\0218 arrizona\r
		}
	10.5.1.12 9901 :mn 90 7f 03
	}

if %mvel -eq 3
	{
	shell /bin/echo -n "\117" >/dev/lp1
	# light 5 & 6 on
	10.5.1.12 9901 :aa ml-2000,-4000,0; gd id
	10.5.1.12 9902 : 19824 se pl\r	
		if %compass -eq 1
		{
#		shell /sound/rsynth/say sky -S 1
		10.5.1.12 9900 :\0218 sky\r
		}
		if %compass -eq 2
		{
#		shell /sound/rsynth/say noon -S 1
		10.5.1.12 9900 :\0218 noon\r
		}
	10.5.1.12 9901 :mn 90 7f 04
	}
      
if %mvel -eq 4
	{
	shell /bin/echo -n "\133" >/dev/lp1
	# light 3 & 6 on
	10.5.1.12 9901 :aa ml6000,4000,-3220; gd id
	10.5.1.12 9902 : 21628 se pl\r	
		if %compass -eq 1
		{
#		shell /sound/rsynth/say south -S 2
		10.5.1.12 9900 :\0218  south\r
		}
		if %compass -eq 2
		{
#		shell /sound/rsynth/say yucaataan -S 2
		10.5.1.12 9900 :\0218 ukahtan\r
		}
	10.5.1.12 9901 :mn 90 7f 05
	}

if %mvel -eq 5
	{
	shell /bin/echo -n "\135" >/dev/lp1
	# light 2 & 6 on
	10.5.1.12 9901 :aa ml4000,0,0; gd id
		if %compass -eq 1
		{
		10.5.1.12 9901 :mn 90 7f 01
#		shell /sound/rsynth/say east -S 2
		10.5.1.12 9900 :\0218 east\r
		set compass 3
		}
		if %compass -eq 2
		{
		10.5.1.12 9901 :mn 90 7f 06
#		shell /sound/rsynth/say oklahoma -S 2
		10.5.1.12 9900 :\0218 oklahoma\r
#		10.5.1.12 9901 :aa vl350,350,350;
		10.5.1.12 9902 : 60 sp
		set compass 1
		}
		if %compass -eq 3
		{
		set compass 2
		}
	}

if %mvel -eq 6
	{
#	shell /bin/echo -n "\037" >/dev/lp1
	shell /bin/echo -n "\337" >/dev/lp1
	# light 6 on
	10.5.1.12 9901 :aa vl350,350,350;
	if %loop -eq 1
		{
		10.5.1.12 9901 :aa ml0,0,0; gd id
		10.5.1.12 9902 : 15070 se\r	
		}
	if %loop -eq 2
		{
		10.5.1.12 9901 :aa ml12000,0,0; gd id
		10.5.1.12 9902 : 15070 se  13986 mr\r	
		}
	10.5.1.12 9901 :mn 90 7f 07
	# light 6
	}


if %mvel -eq 7
	{
	10.5.1.12 9901 :aa ml-4000,0,0; gd id
	10.5.1.12 9902 : 13986 se 14346 mf\r	
	10.5.1.12 9901 :mn 90 7f 08
	}

if %mvel -eq 8
	{
	10.5.1.12 9901 :aa ml0,4000,0; gd id
	10.5.1.12 9902 : 15795 se 16155 mf\r	
	10.5.1.12 9901 :mn 90 7f 09
	}

if %mvel -eq 9
	{
	10.5.1.12 9901 :aa ml0,-4000,0; gd id
	10.5.1.12 9902 : 16155 se 15795 mr\r	
	10.5.1.12 9901 :mn 90 7f 0a
	}

if %mvel -eq 10
	{
	10.5.1.12 9901 :aa ml0,-8000,0; gd id
	10.5.1.12 9902 : 17235 se 16515 mr\r	
	10.5.1.12 9901 :mn 90 7f 0b
	}

if %mvel -eq 11
	{
	if %loop -eq 1
		{
		10.5.1.12 9901 :aa ml-8000,0,0; gd id
		10.5.1.12 9902 : 14346 se 15070 mf\r	
		10.5.1.12 9901 :mn 90 7f 06
		set loop 3
		}
	if %loop -eq 2
		{
		10.5.1.12 9901 :aa ml4000,0,0; gd id
		10.5.1.12 9902 : 14346 se 13986 mr\r	
#		shell /sound/rsynth/say all done -S 2
		10.5.1.12 9900 :\0218 all done\r
#		10.5.1.12 9901 :aa vl500,500,400;
		10.5.1.12 9901 :mn 90 7f 01
		set loop 1
		}
	if %loop -eq 3
		{
		set loop 2
		}
	}

CONFIG
