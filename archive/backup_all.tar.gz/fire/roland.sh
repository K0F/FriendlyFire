#!/bin/bash
actor -d1 -n roland -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.15 9800 :90 3c 40
shell msleep 200
10.5.1.15 9800 :80 3c 70
shell msleep 10

10.5.1.15 9800 :90 3c 50
shell msleep 300
10.5.1.15 9800 :80 3c 70
shell msleep 10

10.5.1.15 9800 :90 3c 60
shell msleep 400
10.5.1.15 9800 :80 3c 70
shell msleep 10

10.5.1.15 9800 :90 3c 60
shell msleep 500
10.5.1.15 9800 :80 3c 70
shell msleep 10

10.5.1.15 9800 :90 3d 40
shell msleep 200
10.5.1.15 9800 :80 3d 70
shell msleep 10

10.5.1.15 9800 :90 3d 50
shell msleep 300
10.5.1.15 9800 :80 3d 70
shell msleep 10

10.5.1.15 9800 :90 3d 60
shell msleep 400
10.5.1.15 9800 :80 3d 70
shell msleep 10

10.5.1.15 9800 :90 3d 60
shell msleep 500
10.5.1.15 9800 :80 3d 70
shell msleep 10

10.5.1.15 9800 :90 3e 40
shell msleep 200
10.5.1.15 9800 :80 3e 70
shell msleep 10

10.5.1.15 9800 :90 3e 50
shell msleep 300
10.5.1.15 9800 :80 3e 70
shell msleep 10

10.5.1.15 9800 :90 3e 60
shell msleep 400
10.5.1.15 9800 :80 3e 70
shell msleep 10

10.5.1.15 9800 :90 3e 60
shell msleep 500
10.5.1.15 9800 :80 3e 70
shell msleep 10

10.5.1.15 9800 :90 3f 40
shell msleep 200
10.5.1.15 9800 :80 3f 70
shell msleep 10

10.5.1.15 9800 :90 3f 50
shell msleep 300
10.5.1.15 9800 :80 3f 70
shell msleep 10

10.5.1.15 9800 :90 3f 60
shell msleep 400
10.5.1.15 9800 :80 3f 70
shell msleep 10

10.5.1.15 9800 :90 3f 60
shell msleep 500
10.5.1.15 9800 :80 3f 70
shell msleep 10

10.5.1.15 9800 :90 40 40
shell msleep 200
10.5.1.15 9800 :80 40 70
shell msleep 10

10.5.1.15 9800 :90 40 50
shell msleep 300
10.5.1.15 9800 :80 40 70
shell msleep 10

10.5.1.15 9800 :90 40 60
shell msleep 400
10.5.1.15 9800 :80 40 70
shell msleep 10

10.5.1.15 9800 :90 40 60
shell msleep 500
10.5.1.15 9800 :80 40 70
shell msleep 10

10.5.1.15 9800 :90 41 40
shell msleep 200
10.5.1.15 9800 :80 41 70
shell msleep 10

10.5.1.15 9800 :90 41 50
shell msleep 300
10.5.1.15 9800 :80 41 70
shell msleep 10

10.5.1.15 9800 :90 41 60
shell msleep 400
10.5.1.15 9800 :80 41 70
shell msleep 10

10.5.1.15 9800 :90 41 60
shell msleep 500
10.5.1.15 9800 :80 41 70
shell msleep 10

10.5.1.15 9800 :90 42 40
shell msleep 200
10.5.1.15 9800 :80 42 70
shell msleep 10

10.5.1.15 9800 :90 42 50
shell msleep 300
10.5.1.15 9800 :80 42 70
shell msleep 10

10.5.1.15 9800 :90 42 60
shell msleep 400
10.5.1.15 9800 :80 42 70
shell msleep 10

10.5.1.15 9800 :90 42 70
shell msleep 500
10.5.1.15 9800 :80 42 70
shell msleep 10

10.5.1.15 9800 :90 43 40
shell msleep 200
10.5.1.15 9800 :80 43 70
shell msleep 10

10.5.1.15 9800 :90 43 50
shell msleep 300
10.5.1.15 9800 :80 43 70
shell msleep 10

10.5.1.15 9800 :90 43 60
shell msleep 400
10.5.1.15 9800 :80 43 70
shell msleep 10

10.5.1.15 9800 :90 43 60
shell msleep 500
10.5.1.15 9800 :80 43 70
shell msleep 10

10.5.1.15 9800 :90 44 40
shell msleep 200
10.5.1.15 9800 :80 44 70
shell msleep 10

10.5.1.15 9800 :90 44 50
shell msleep 300
10.5.1.15 9800 :80 44 70
shell msleep 10

10.5.1.15 9800 :90 44 60
shell msleep 400
10.5.1.15 9800 :80 44 70
shell msleep 10

10.5.1.15 9800 :90 44 60
shell msleep 500
10.5.1.15 9800 :80 44 70
shell msleep 10

10.5.1.15 9800 :90 45 40
shell msleep 200
10.5.1.15 9800 :80 45 70
shell msleep 10

10.5.1.15 9800 :90 45 50
shell msleep 300
10.5.1.15 9800 :80 45 70
shell msleep 10

10.5.1.15 9800 :90 45 60
shell msleep 400
10.5.1.15 9800 :80 45 70
shell msleep 10

10.5.1.15 9800 :90 45 60
shell msleep 500
10.5.1.15 9800 :80 45 70
shell msleep 10

10.5.1.15 9800 :90 46 40
shell msleep 200
10.5.1.15 9800 :80 46 70
shell msleep 10

10.5.1.15 9800 :90 46 50
shell msleep 300
10.5.1.15 9800 :80 46 70
shell msleep 10

10.5.1.15 9800 :90 46 60
shell msleep 400
10.5.1.15 9800 :80 46 70
shell msleep 10

10.5.1.15 9800 :90 46 60
shell msleep 500
10.5.1.15 9800 :80 46 70
shell msleep 10

10.5.1.15 9800 :90 47 40
shell msleep 200
10.5.1.15 9800 :80 47 70
shell msleep 10

10.5.1.15 9800 :90 47 50
shell msleep 300
10.5.1.15 9800 :80 47 70
shell msleep 10

10.5.1.15 9800 :90 47 60
shell msleep 400
10.5.1.15 9800 :80 47 70
shell msleep 10

10.5.1.15 9800 :90 47 60
shell msleep 500
10.5.1.15 9800 :80 47 70
shell msleep 10

10.5.1.15 9800 :90 48 40
shell msleep 200
10.5.1.15 9800 :80 48 70
shell msleep 10

10.5.1.15 9800 :90 48 50
shell msleep 300
10.5.1.15 9800 :80 48 70
shell msleep 10

10.5.1.15 9800 :90 48 60
shell msleep 400
10.5.1.15 9800 :80 48 70
shell msleep 10

10.5.1.15 9800 :90 48 70
shell msleep 500
10.5.1.15 9800 :80 48 70
shell msleep 10

10.5.1.15 9800 :90 49 40
shell msleep 200
10.5.1.15 9800 :80 49 70
shell msleep 10

10.5.1.15 9800 :90 49 50
shell msleep 300
10.5.1.15 9800 :80 49 70
shell msleep 10

10.5.1.15 9800 :90 49 60
shell msleep 400
10.5.1.15 9800 :80 49 70
shell msleep 10

10.5.1.15 9800 :90 49 60
shell msleep 500
10.5.1.15 9800 :80 49 70
shell msleep 10

10.5.1.15 9800 :90 4a 40
shell msleep 200
10.5.1.15 9800 :80 4a 70
shell msleep 10

10.5.1.15 9800 :90 4a 50
shell msleep 300
10.5.1.15 9800 :80 4a 70
shell msleep 10

10.5.1.15 9800 :90 4a 60
shell msleep 400
10.5.1.15 9800 :80 4a 70
shell msleep 10

10.5.1.15 9800 :90 4a 60
shell msleep 500
10.5.1.15 9800 :80 4a 70
shell msleep 10

10.5.1.15 9800 :90 4b 40
shell msleep 200
10.5.1.15 9800 :80 4b 70
shell msleep 10

10.5.1.15 9800 :90 4b 50
shell msleep 300
10.5.1.15 9800 :80 4b 70
shell msleep 10

10.5.1.15 9800 :90 4b 60
shell msleep 400
10.5.1.15 9800 :80 4b 70
shell msleep 10

10.5.1.15 9800 :90 4b 60
shell msleep 500
10.5.1.15 9800 :80 4b 70
shell msleep 10

10.5.1.15 9800 :90 4c 40
shell msleep 200
10.5.1.15 9800 :80 4c 70
shell msleep 10

10.5.1.15 9800 :90 4c 50
shell msleep 300
10.5.1.15 9800 :80 4c 70
shell msleep 10

10.5.1.15 9800 :90 4c 60
shell msleep 400
10.5.1.15 9800 :80 4c 70
shell msleep 10

10.5.1.15 9800 :90 4c 60
shell msleep 500
10.5.1.15 9800 :80 4c 70
shell msleep 10

10.5.1.15 9800 :90 4d 40
shell msleep 200
10.5.1.15 9800 :80 4d 70
shell msleep 10

10.5.1.15 9800 :90 4d 50
shell msleep 300
10.5.1.15 9800 :80 4d 70
shell msleep 10

10.5.1.15 9800 :90 4d 60
shell msleep 750
10.5.1.15 9800 :80 4d 70
shell msleep 10

10.5.1.15 9800 :90 4d 60
shell msleep 1000
10.5.1.15 9800 :80 4d 70
shell msleep 10

10.5.1.15 9800 :90 4e 40
shell msleep 200
10.5.1.15 9800 :80 4e 70
shell msleep 10

10.5.1.15 9800 :90 4e 50
shell msleep 300
10.5.1.15 9800 :80 4e 70
shell msleep 10

10.5.1.15 9800 :90 4e 60
shell msleep 750
10.5.1.15 9800 :80 4e 70
shell msleep 10

10.5.1.15 9800 :90 60
shell msleep 1000
10.5.1.15 9800 :80 70
shell msleep 10

10.5.1.15 9800 :90 4f 40
shell msleep 200
10.5.1.15 9800 :80 4f 70
shell msleep 10

10.5.1.15 9800 :90 4f 50
shell msleep 300
10.5.1.15 9800 :80 4f 70
shell msleep 10

10.5.1.15 9800 :90 4f 60
shell msleep 750
10.5.1.15 9800 :80 4f 70
shell msleep 10

10.5.1.15 9800 :90 4f 60
shell msleep 1000
10.5.1.15 9800 :80 4f 70
shell msleep 10

10.5.1.15 9800 :90 50 40
shell msleep 200
10.5.1.15 9800 :80 50 70
shell msleep 10

10.5.1.15 9800 :90 50 50
shell msleep 300
10.5.1.15 9800 :80 50 70
shell msleep 10

10.5.1.15 9800 :90 50 60
shell msleep 750
10.5.1.15 9800 :80 50 70
shell msleep 10

10.5.1.15 9800 :90 50 60
shell msleep 1000
10.5.1.15 9800 :80 50 70
shell msleep 10

CONFIG
