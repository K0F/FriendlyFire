#!/bin/sh
#actor -d2 -n pad3 -h 10.5.1.15 -p 9850 -f pad3.log << CONFIG
actor -d0 -n pad3 -h 10.5.1.15 -p 9850 << CONFIG
10.5.1.15 9800 midi
   note_on
   midi_channel 9 
   low   0x2a
   hi    0x2a
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

if %video_mode -eq 1
{
if %mvel -ge 1
      {
      if %mvel -lt 22    
      10.5.1.15 9900 :25988 se pl\r
      }
      
if %mvel -ge 22
      {
      if %mvel -lt 43    
      10.5.1.15 9900 :26830 se pl\r
      }
      
if %mvel -ge 43
      {
      if %mvel -lt 64    
      10.5.1.15 9900 :27120 se pl\r
      }

if %mvel -ge 64
      {
      if %mvel -lt 85    
      10.5.1.15 9900 :27485 se pl\r
      } 

if %mvel -ge 85
      {
      if %mvel -lt 106
      10.5.1.15 9900 :27902 se pl\r
      }

if %mvel -ge 106
      {
      if %mvel -lt 127
      10.5.1.15 9900 :28866 se pl\r
      }
}
      
CONFIG
