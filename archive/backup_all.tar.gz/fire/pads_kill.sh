#!/bin/bash
actor -d0 -n pads_kill -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

shell cat /var/run/actor.pad1.pid | xargs kill
shell cat /var/run/actor.pad2.pid | xargs kill
shell cat /var/run/actor.pad3.pid | xargs kill
shell cat /var/run/actor.pad4.pid | xargs kill
shell cat /var/run/actor.pad5.pid | xargs kill


CONFIG
