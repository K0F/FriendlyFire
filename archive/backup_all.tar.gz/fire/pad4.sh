#!/bin/sh
#actor -d2 -n pad4 -h 10.5.1.15 -p 9850 -f pad4.log << CONFIG
actor -d0 -n pad4 -h 10.5.1.15 -p 9850 << CONFIG
10.5.1.15 9800 midi
   note_on
   midi_channel 9 
   low   0x31
   hi    0x31
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

if %video_mode -eq 1
{
if %mvel -ge 1
      {
      if %mvel -lt 15    
      10.5.1.15 9900 :0sp mr\r
      }
      
if %mvel -ge 15
      {
      if %mvel -lt 29    
      10.5.1.15 9900 :4sp mr\r
      }
      
if %mvel -ge 29
      {
      if %mvel -lt 43    
      10.5.1.15 9900 :8sp mr\r
      }

if %mvel -ge 43
      {
      if %mvel -lt 57    
      10.5.1.15 9900 :15sp mr\r
      } 

if %mvel -ge 57
      {
      if %mvel -lt 71
      10.5.1.15 9900 :30sp mr\r
      }

if %mvel -ge 71
      {
      if %mvel -lt 85
      10.5.1.15 9900 :60sp mr\r
      }

if %mvel -ge 85
      {
      if %mvel -lt 99
      10.5.1.15 9900 :120sp mr\r
      }
      
if %mvel -ge 99
      {
      if %mvel -lt 113
      10.5.1.15 9900 :240sp mr\r
      }
if %mvel -ge 113
      {
      if %mvel -le 127
      10.5.1.15 9900 :255sp mr\r
      }
}
      
CONFIG
