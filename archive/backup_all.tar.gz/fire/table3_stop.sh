#!/bin/sh
actor -d1 -n table3_stop.sh -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end
   
shell echo stopping table3 >>/var/log/table3.log
shell date >>/var/log/table3.log
shell /actors/p0-7_off.sh &
shell /actors/video_rj.sh &

shell sleep 1
shell kill `ps -ax | grep 'bash /actors/check_and_restart.sh' | grep -v grep | awk '{print $1}'`
shell killall actor

CONFIG
