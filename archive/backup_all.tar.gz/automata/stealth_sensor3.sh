#!/bin/sh
actor -d0 -n stealth_sensor3 -h 10.5.1.12 -p 9850 << CONFIG
10.5.1.12 9800 midi
   note_on
   midi_channel 4
   low   0x03
   hi    0x03
   low_velocity   0x00
   hi_velocity    0x7f
   end

set activity 1

set switcher 1

10.5.1.14 9901 :Axdx\r

if %frame -gt 54000
	{
	shell makerandom 200 500 > currentrandom.txt
	shell hpcp -d0 -l -h 10.5.1.12 -p 9850 -f currentrandom.txt
	set frame %random
	}

set frame %frame+%random

10.5.1.17 9901 : %frame se 40 sp mf\r

if %xlimit -ne 3
	{
	# jog right
	10.5.1.17 9900 :ax jg800
	}
	
CONFIG

