#!/bin/sh
actor -d0 -n stealth_xloop -h 10.5.1.12 -p 9850 << CONFIG
10.5.1.12 9900 midi
   note_on
   midi_channel 15
   low   0x7f
   hi    0x7f
   low_velocity   0x00
   hi_velocity    0x7f
   end

if %mvel -eq 0
        {
        10.5.1.17 9900 :ax ma-10000; gd id
        10.5.1.17 9900 :mn 9f 7f 01
        }

if %mvel -eq 1
        {
        10.5.1.17 9900 :ax ma10000; gd id
        10.5.1.17 9900 :mn 9f 7f 00
         }

CONFIG

