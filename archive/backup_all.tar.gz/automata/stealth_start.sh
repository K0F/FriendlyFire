#!/bin/sh
actor -d0 -n stealth_start -h 10.5.1.12 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

set frame 1
set random 300
set video_input 1
10.5.1.17 9901 :pl\r
10.5.1.14 9901 :Cxdx\r
shell /actors/stealth_activity.sh &
shell /actors/stealth_dimmer.sh &
shell /actors/stealth_xjog.sh &
shell /actors/stealth_yjog.sh &
shell /actors/stealth_tjog.sh &
#shell /actors/stealth_xlimit.sh &
#shell /actors/stealth_ylimit.sh &
#shell /actors/stealth_tlimit.sh &
shell /actors/stealth_sensor1.sh &
shell /actors/stealth_sensor2.sh &
shell /actors/stealth_sensor3.sh &
shell /actors/stealth_sensor4.sh &
shell /actors/stealth_video_switch.sh &
shell /actors/stealth_video_64rb.sh &
10.5.1.17 9900 :ax jg200
10.5.1.17 9900 :ay jg100
10.5.1.17 9900 :at jg100

CONFIG
