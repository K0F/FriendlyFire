#!/bin/sh
actor -d0 -n stealth_xright -h 10.5.1.12 -p 9850 << CONFIG
10.5.1.12 9800 midi
   note_on
   midi_channel 3
   low   0x3c
   hi    0x3c
   low_velocity   0x00
   hi_velocity    0x7f
   end

10.5.1.17 9900 :ax st
10.5.1.17 9900 :ax ma10000; gd id
10.5.1.17 9900 :mn 9f 7f 00

if %frame -gt 54000
	{
	shell makerandom 500 1000 > currentrandom.txt
	shell hpcp -d0 -l -h 10.5.1.12 -p 9850 -f currentrandom.txt
	set frame %random
	}

set frame %frame+%random

10.5.1.17 9901 : %frame se mr\r

CONFIG

