#!/bin/sh
actor -d0 -n automata_midi2 -h 10.5.1.12 -p 9850 << CONFIG
10.5.1.12 9901 midi
   note_on
   midi_channel 0 
   low   0x7f
   hi    0x7f
   low_velocity   0x01
   hi_velocity    0x7f 
   end

if %mvel -eq 1
	{
	10.5.1.12 9901 :aa ml4000,0,0; gd id
	10.5.1.12 9902 : 19369 se pl\r	
		if %compass -eq 1
		{
		shell /sound/rsynth/say north
		}
		if %compass -eq 2
		{
		shell /sound/rsynth/say saskatchewan
		}
	10.5.1.12 9901 :mn 90 7f 02
	# go home all axes
	}

if %mvel -eq 2
	{
	10.5.1.12 9901 :aa ml4000,0,3220; gd id
	10.5.1.12 9902 : 20388 se pl\r	
		if %compass -eq 1
		{
		shell /sound/rsynth/say west
		}
		if %compass -eq 2
		{
		shell /sound/rsynth/say arizona
		}
	10.5.1.12 9901 :mn 90 7f 03
	}

if %mvel -eq 3
	{
	10.5.1.12 9901 :aa ml-2000,-4000,0; gd id
	10.5.1.12 9902 : 19824 se pl\r	
		if %compass -eq 1
		{
		shell /sound/rsynth/say sky
		}
		if %compass -eq 2
		{
		shell /sound/rsynth/say noon
		}
	10.5.1.12 9901 :mn 90 7f 04
	}
      
if %mvel -eq 4
	{
	10.5.1.12 9901 :aa ml6000,4000,-3220; gd id
	10.5.1.12 9902 : 21628 se pl\r	
		if %compass -eq 1
		{
		shell /sound/rsynth/say south
		}
		if %compass -eq 2
		{
		shell /sound/rsynth/say ukatan
		}
	10.5.1.12 9901 :mn 90 7f 05
	}

if %mvel -eq 5
	{
	10.5.1.12 9901 :aa ml4000,0,0; gd id
		if %compass -eq 1
		{
		10.5.1.12 9901 :mn 90 7f 01
		shell /sound/rsynth/say east
		set compass 3
		}
		if %compass -eq 2
		{
		10.5.1.12 9901 :mn 90 7f 01
		shell /sound/rsynth/say oklahoma
		set compass 1
		}

		if %compass -eq 3
		{
		set compass 2
		}
	}

CONFIG
