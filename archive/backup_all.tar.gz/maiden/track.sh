#!/bin/bash
actor -d1 -n track6 -h 10.5.1.9 -p 9850 << CONFIG
10.5.1.9 9800 midi
   note_on
   midi_channel 0 
   low   0x01
   hi    0x01 
   low_velocity   0x01
   hi_velocity    0x6f 
   end


if %mvel -ge 1
      {
      if %mvel -lt 16
      {
      if %pos1 -eq 1  
      { 
10.5.1.10 9700 :pos 01 20000
10.5.1.10 9700 :traj 01
10.5.1.10 9700 :go 01
set pos1 0
set pos2 1
set pos3 1
set pos4 1
set pos5 1
set pos6 1
set pos7 1
       }
      }
     }

if %mvel -ge 16
      {
      if %mvel -lt 32
      {
      if %pos2 -eq 1  
      { 
10.5.1.10 9700 :pos 01 14000
10.5.1.10 9700 :traj 01
10.5.1.10 9700 :go 01
set pos1 1
set pos2 0
set pos3 1
set pos4 1
set pos5 1
set pos6 1
set pos7 1
       }
      }
     }
      
if %mvel -ge 32
      {
      if %mvel -lt 48
      {
      if %pos3 -eq 1  
      { 
10.5.1.10 9700 :pos 01 7000
10.5.1.10 9700 :traj 01
10.5.1.10 9700 :go 01
set pos1 1
set pos2 1
set pos3 0
set pos4 1
set pos5 1
set pos6 1
set pos7 1
       }
      }
     }

if %mvel -ge 48
       {
      if %mvel -lt 64
      {
      if %pos4 -eq 1  
      { 
10.5.1.10 9700 :pos 01 0
10.5.1.10 9700 :traj 01
10.5.1.10 9700 :go 01
set pos1 1
set pos2 1
set pos3 1
set pos4 0
set pos5 1
set pos6 1
set pos7 1
       }
      }
     }
     
if %mvel -ge 64
       {
      if %mvel -lt 80
      {
      if %pos5 -eq 1  
      { 
10.5.1.10 9700 :pos 01 -7000
10.5.1.10 9700 :traj 01
10.5.1.10 9700 :go 01
set pos1 1
set pos2 1
set pos3 1
set pos4 1
set pos5 0
set pos6 1
set pos7 1
       }
      }
     }

if %mvel -ge 80
       {
      if %mvel -lt 96
      {
      if %pos6 -eq 1  
      { 
10.5.1.10 9700 :pos 01 -14000
10.5.1.10 9700 :traj 01
10.5.1.10 9700 :go 01
set pos1 1
set pos2 1
set pos3 1
set pos4 1
set pos5 1
set pos6 0
set pos7 1
       }
      }
     }

if %mvel -ge 96
       {
      if %mvel -lt 96
      {
      if %pos7 -eq 1  
      { 
10.5.1.10 9700 :pos 01 -20000
10.5.1.10 9700 :traj 01
10.5.1.10 9700 :go 01
set pos1 1
set pos2 1
set pos3 1
set pos4 1
set pos5 1
set pos6 1
set pos7 0
       }
      }
     }



CONFIG
