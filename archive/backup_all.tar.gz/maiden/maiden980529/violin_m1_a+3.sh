#!/bin/bash
# pelvic lift(8) off
actor -d1 -n violin_m1_a+3 n -h 10.5.1.9 -p 9850 << CONFIG
10.5.1.14 9800 midi
   note_on
   midi_channel 0 
   low   0x3a 
   hi    0x3a 
   low_velocity   0x01
   hi_velocity    0x70 
   end

10.5.1.14 9900 :FCL100

CONFIG
