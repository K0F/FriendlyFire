#!/bin/sh
actor -d0 -n test2 -h 10.5.1.9 -p 9850 << CONFIG
10.5.1.3 9800 midi
   note_on
   midi_channel 0 
   low   0x20 
   hi    0x70 
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

# this is a comment
shell echo here 1

if %var1 -eq 1
   {
   shell echo here 2

#  if %var2 -eq 2
#      10.5.1.10 9700 : nop 01
  }

if %mnote -eq 42
   { 
   shell echo note 2a
   10.5.1.10 9700 : nop 01
   }
   
if %mnote -eq 43
   10.5.1.9 9900 :10\r

if %mnote -eq 44
   10.5.1.9 9900 :14\r

if %mnote -eq 45
   10.5.1.9 9900 :11\r

CONFIG
