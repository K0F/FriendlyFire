#!/bin/bash
actor -d1 -n track_init -h 10.5.1.9 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

set pos1 1
set pos2 1
set pos3 1
set pos4 1
set pos5 1
set pos6 1
set pos7 1


CONFIG
