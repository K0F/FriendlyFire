#!/bin/bash
actor -d1 -n optomux -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 0
   end

#10.5.1.15 9900 :FDL01
10.5.1.15 9900 :FEL08
10.5.1.15 9900 :FEK01
#shell sleep 1

#10.5.1.15 9900 :FDL01
10.5.1.15 9900 :FEL01
10.5.1.15 9900 :FEK02
#shell sleep 1

#10.5.1.15 9900 :FDL01
10.5.1.15 9900 :FEL02
10.5.1.15 9900 :FEK04
#shell sleep 1 

#10.5.1.15 9900 :FDL01
10.5.1.15 9900 :FEL04
10.5.1.15 9900 :FEK08

CONFIG
