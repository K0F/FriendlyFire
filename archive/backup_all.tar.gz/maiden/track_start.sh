#track_init.sh
track1.sh &
track2.sh &
track3.sh &
track4.sh &
track5.sh &
track6.sh &
track7.sh &
