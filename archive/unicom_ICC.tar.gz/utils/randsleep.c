/*
*  randsleep.c
*  sleep for a random time, upto the value specified in the 
*  calling argument
*
*  calling format:  randsleep <maxlength>
*  returns: random slept value in milliseconds (also echoed to stdout)
*/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
long tdel;

if (argc < 2)
	{
	printf("calling format is randsleep <maxdelay> where maxdelay is milliseconds\n");
	exit(0);
	}

srand((unsigned int)time(NULL));
sscanf(argv[1], "%ld", &tdel);
tdel *= 1000L;

tdel=1L+(long)((float)tdel*rand()/(RAND_MAX+1.0));
/* printf("sleeping for %ld milliseconds\n",tdel/1000L); */

usleep(tdel);

printf("%d\n",tdel/1000L);
exit((int)(tdel/1000L));
}
