#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
int i;
FILE *infile;
FILE *outfile;
char string[255];

if (argc < 3)
	{
	printf("calling format is linecount <infile> <outfile>\n");
	exit(0);
	}

infile = fopen(argv[1],"r");
if (infile == NULL)
   {
   printf("Error opening %s as input\n",argv[1]);
   exit(-1);	
   }
i=0;
while (fgets(string,254,infile) != NULL)
   i++;

outfile = fopen(argv[2],"w");
if (outfile == NULL)
   {
   printf("Error opening %s as output\n",argv[2]);
   exit(-1);	
   }
while(i>0)
   {
   fprintf(outfile,"^");
   i--;
   }
fprintf(outfile,"\n");


}
