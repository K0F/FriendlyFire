#!/bin/sh
#actor -d1 -n pad1 -h 10.5.1.15 -p 9850 -f pad1.log << CONFIG
actor -d0 -n pad1 -h 10.5.1.15 -p 9850 << CONFIG
10.5.1.15 9800 midi
   note_on
   midi_channel 9 
   low   0x23
   hi    0x23
   low_velocity   0x01 
   hi_velocity    0x7f 
   end

if %video_mode -eq 1
{
if %mvel -ge 1
      {
      if %mvel -lt 22    
      10.5.1.15 9900 :1000 se pl\r
      }
      
if %mvel -ge 22
      {
      if %mvel -lt 43    
      10.5.1.15 9900 :3715 se pl\r
      }
      
if %mvel -ge 43
      {
      if %mvel -lt 64    
      10.5.1.15 9900 :8131 se pl\r
      }

if %mvel -ge 64
      {
      if %mvel -lt 85    
      10.5.1.15 9900 :9350 se pl\r
      } 

if %mvel -ge 85
      {
      if %mvel -lt 106
      10.5.1.15 9900 :11380 se pl\r
      }

if %mvel -ge 106
      {
      if %mvel -lt 127
      10.5.1.15 9900 :16142 se pl\r
      }
 }     
CONFIG
