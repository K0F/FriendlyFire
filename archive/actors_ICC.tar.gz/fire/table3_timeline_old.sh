#!/bin/bash
actor -d2 -n table3_timeline -f /var/log/t3time.log -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 0
   end

	shell cd /actors
	shell p0-on_p2-on_p5-on.sh
	set video_mode 1
	shell video_5se3200pl.sh

shell sleep 3

	shell p5-on.sh

shell sleep 27

	shell video_64rb.sh

shell sleep 76

	shell video_3261se10303pl.sh

shell sleep 224

	shell p0-on_p2-on_p5-on.sh

shell sleep 10

	shell p0-on_p1-on_p4-on.sh
	set video_mode 0
	shell video_1se.sh
	
shell sleep 5
	
	shell p4-on.sh

shell sleep 5

	shell slide_11.sh &

shell sleep 2

	shell video_29082sepl.sh

shell sleep 108

	shell p3-on_p4-on.sh
	shell p0-on_p1-on_p4-on.sh

shell sleep 10

	shell p0-on_p2-on_p5-on.sh

shell sleep 2

	set video_mode 1
	shell video_16142se29043pl.sh

shell sleep 5
	
	shell p5-on.sh

shell sleep 437

	shell p0-on_p2-on_p5-on.sh

shell sleep 10

	shell p0-on_p1-on_p4-on.sh
	set video_mode 0

shell sleep 5

	shell p4-on.sh
	
shell sleep 5

	shell slide_11.sh &

shell sleep 2

	shell video_34000sepl.sh

shell sleep 108

	shell p3-on_p4-on.sh
	shell p0-on_p1-on_p4-on.sh

shell sleep 10

	shell p0-on_p2-on_p5-on.sh

CONFIG
