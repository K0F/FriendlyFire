#!/bin/sh
# 6 is on all the time
actor -d0 -n p0-on_p2-on_p5-on -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

shell /bin/echo -n "\232" >/dev/lp2
      
CONFIG
