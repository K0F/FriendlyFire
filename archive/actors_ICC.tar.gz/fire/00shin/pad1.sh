#!/bin/sh
#
while [ 1 ] ; do
  sleep 10
done
