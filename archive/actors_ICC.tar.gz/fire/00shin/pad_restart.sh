#!/bin/bash
actor -d0 -n pad_restart.sh -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 30
   iterations 0
   end

if %pad -eq 1
	{
	shell pad1_check.sh
	}

if %pad -eq 2
	{
	shell pad2_check.sh
	}
	
if &pad -eq 3
	{
	shell pad3_check.sh
	}
	
if %pad -eq 4
	{
	shell pad4_check.sh
	}
	
if %&pad -eq 5
	{
	shell pad5_check.sh
	set pad 0
	}
	
set pad %pad+1



CONFIG
