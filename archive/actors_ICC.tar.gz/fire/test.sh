#!/bin/sh
actor -d1 -n test -h 10.5.1.15 -p 9850 << CONFIG
localhost 0 immediate
   test_delay 0
   loop_delay 1
   iterations 10
   end

set test %test+1

if %test -eq 1
10.5.1.14 9800 :90 1 1

if %test -eq 2
10.5.1.14 9800 :90 2 1

if %test -eq 3
10.5.1.14 9800 :90 3 1

if %test -eq 4
10.5.1.14 9800 :90 4 1

if %test -eq 5
10.5.1.14 9800 :90 5 1

if %test -eq 6
10.5.1.14 9800 :90 6 1

if %test -eq 7
10.5.1.14 9800 :90 7 1

if %test -eq 8
10.5.1.14 9800 :90 8 1

if %test -eq 9
10.5.1.14 9800 :90 9 1

if %test -eq 10
10.5.1.14 9800 :90 a 1

CONFIG
