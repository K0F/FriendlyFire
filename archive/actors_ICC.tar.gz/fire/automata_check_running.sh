#!/bin/sh
actor -d0 -n automata_check_running -h 10.5.1.12 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 0
   end

set running 0

shell sleep 60

if %running -eq 0
	shell automata_init.sh
  
CONFIG
