#!/bin/bash
# arm left & right(5)(6) on
actor -d1 -n violin_m4_d5 -h 10.5.1.9 -p 9850 << CONFIG
10.5.1.14 9800 midi
   note_on
   midi_channel 3 
   low   0x4a 
   hi    0x4a 
   low_velocity   0x01
   hi_velocity    0x70 
   end

10.5.1.14 9900 :FCK60

CONFIG
