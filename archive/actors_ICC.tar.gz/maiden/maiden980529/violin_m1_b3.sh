#!/bin/bash
# ft str, leg decl,  knee drop, pelv roll+lift (2)(8)(9)(10)(11) on
actor -d1 -n violin_m1_b3 n -h 10.5.1.9 -p 9850 << CONFIG
10.5.1.14 9800 midi
   note_on
   midi_channel 0 
   low   0x3b 
   hi    0x3b 
   low_velocity   0x01
   hi_velocity    0x70 
   end

10.5.1.14 9900 :FCKF04

CONFIG
