#!/bin/bash
# both fans, both arms (5)(6)(13)(14) on
actor -d1 -n violin_m5_d6 -h 10.5.1.9 -p 9850 << CONFIG
10.5.1.14 9800 midi
   note_on
   midi_channel 4 
   low   0x56 
   hi    0x56 
   low_velocity   0x01
   hi_velocity    0x70 
   end

10.5.1.14 9900 :FCK6060

CONFIG
