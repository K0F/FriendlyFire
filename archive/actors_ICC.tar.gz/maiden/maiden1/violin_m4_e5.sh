#!/bin/bash
actor -d1 -n violin_m4_e5 -h 10.5.1.9 -p 9850 << CONFIG
10.5.1.15 9800 midi
   note_on
   midi_channel 3 
   low   0x4c 
   hi    0x4c 
   low_velocity   0x01
   hi_velocity    0x70 
   end

10.5.1.15 9900 :FCKC00

CONFIG
