#!/bin/bash
actor -d1 -n midi_fast -h 10.5.1.9 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.9 9800 :90 3c 40
10.5.1.9 9800 :80 3c 70

10.5.1.9 9800 :90 3c 50
10.5.1.9 9800 :80 3c 70

10.5.1.9 9800 :90 3c 60
10.5.1.9 9800 :80 3c 70

10.5.1.9 9800 :90 3c 60
10.5.1.9 9800 :80 3c 70

10.5.1.9 9800 :90 3d 40
10.5.1.9 9800 :80 3d 70

CONFIG
