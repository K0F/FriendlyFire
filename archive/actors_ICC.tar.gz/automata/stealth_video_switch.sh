#!/bin/sh
actor -d0 -n stealth_video_switch -h 10.5.1.12 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 0
   end

set switcher 0

shell msleep 1000

if %switcher -ne 0
	{
	if %video_input -eq 1
		{
		10.5.1.14 9901 :Bxdx\r
		set video_input 3 
		}
	if %video_input -eq 2
		{
		10.5.1.14 9901 :Cxdx\r
		set video_input 1
		}
	if %video_input -eq 3
		{
		set video_input 2
		}
	}
	
CONFIG
