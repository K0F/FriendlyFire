#!/bin/sh
# stop disc rotation
actor -d0 -n stealth_video_rj -h 10.5.1.12 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.17 9901 :rj\r
     
CONFIG
