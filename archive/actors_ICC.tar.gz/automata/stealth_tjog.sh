#!/bin/sh
actor -d0 -n stealth_tjog -h 10.5.1.12 -p 9850 << CONFIG
10.5.1.12 9800 midi
   note_on
   midi_channel 3
   low   0x01
   hi    0x03
   low_velocity   0x00
   hi_velocity    0x7f
   end

if %mnote -eq 1
	10.5.1.17 9900 :at jg50
	
if %mnote -eq 3
	10.5.1.17 9900 :at jg-50
	
set tlimit %mnote


CONFIG
