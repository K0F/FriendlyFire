#!/bin/sh
# switch video
actor -d0 -n video_switch -h 10.5.1.12 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

10.5.1.10 9902 :88\r
      
CONFIG
