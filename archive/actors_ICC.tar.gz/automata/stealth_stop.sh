#!/bin/sh
actor -d0 -n stealth_stop -h 10.5.1.12 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end

shell /actors/stealth_video_rj.sh &
10.5.1.10 9901 :F0\rD13-15@0\rG\r
#10.5.1.17 9900 :aa st
shell cat /var/run/actor.stealth_activity.pid | xargs kill
shell cat /var/run/actor.stealth_dimmer.pid | xargs kill
shell cat /var/run/actor.stealth_xjog.pid | xargs kill
shell cat /var/run/actor.stealth_yjog.pid | xargs kill
shell cat /var/run/actor.stealth_tjog.pid | xargs kill
shell cat /var/run/actor.stealth_sensor1.pid | xargs kill
shell cat /var/run/actor.stealth_sensor2.pid | xargs kill
shell cat /var/run/actor.stealth_sensor3.pid | xargs kill
shell cat /var/run/actor.stealth_sensor4.pid | xargs kill
shell cat /var/run/actor.stealth_video_switch.pid | xargs kill
10.5.1.17 9900 :aa st

CONFIG
