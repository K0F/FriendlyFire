#!/bin/sh
actor132 -d1 -n automata_init -h 10.5.1.12 -p 9850 << CONFIG
localhost 0 immediate
   init_delay 0
   loop_delay 0
   iterations 1
   end


set compass 1
set loop 1

shell cat /var/run/actor.automata_midi.pid | xargs kill

shell sleep 1

10.5.1.12 9900 :\0218 trying to restart\r

shell /actors/automata_midi.sh &

shell sleep 5

10.5.1.12 9901 :aa st
10.5.1.12 9901 :aa ac1000,1000,1000;
10.5.1.12 9901 :aa vl500,500,300;
10.5.1.12 9901 :ax hm0 ay hm0 az hm0; go
10.5.1.12 9901 :ax ca ay ca az ca
10.5.1.12 9901 :aa mt0,0,0; gd id
10.5.1.12 9901 :mn 90 7f 00

#10.5.1.12 9900 :\0218 trying to restart\r

shell echo attempted restart >>/var/log/omsdd.log
shell date >>/var/log/omsdd.log

10.5.1.12 9901 :rp


CONFIG
